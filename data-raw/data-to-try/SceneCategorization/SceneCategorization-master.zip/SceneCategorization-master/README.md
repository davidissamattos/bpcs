# SceneCategorization
Data and analysis code for Zhang &amp; Houpt (2017)
